"""
HackerRank Orchestrate - "Buy or Wait?" Financial Agent
Main entry point. Processes all requests and generates output.csv.
"""
import os
import sys
import time
import pandas as pd
from pathlib import Path
from dotenv import load_dotenv

# Add code/ to path
sys.path.insert(0, str(Path(__file__).parent))

from agent.ocr import OCRService
from agent.simulator import Simulator
from agent.pipeline import Pipeline
from agent.explainer import Explainer


def main():
    load_dotenv()

    start_time = time.time()
    data_dir = os.path.join(os.path.dirname(__file__), '..', 'dataset')
    data_dir = os.path.normpath(data_dir)

    print("=" * 60)
    print("HackerRank Orchestrate - Buy or Wait? Financial Agent")
    print("=" * 60)

    # Detect if LLM is available
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    use_mock = not bool(api_key)
    if use_mock:
        print("[WARN] No GEMINI_API_KEY or GOOGLE_API_KEY found. Running in mock/template mode.")
    else:
        print("[INFO] Using Google GenAI (gemini-2.5-flash) for OCR and explanations.")

    # Initialize services
    print("\n[1/5] Initializing services...")
    ocr_service = OCRService(data_dir=data_dir, use_mock=use_mock)
    simulator = Simulator(data_dir=data_dir, ocr_service=ocr_service)
    pipeline = Pipeline(simulator, data_dir=data_dir)
    explainer = Explainer(use_mock=use_mock)

    # Load requests
    is_sample = len(sys.argv) > 1 and sys.argv[1] == '--sample'
    filename = "sample_requests.csv" if is_sample else "requests.csv"
    requests_df = pd.read_csv(f"{data_dir}/{filename}")
    total = len(requests_df)
    print(f"[2/5] Loaded {total} requests to process from {filename}.")

    # Process each request
    print(f"[3/5] Processing requests...")
    results = []
    profiles = pd.read_csv(f"{data_dir}/financial_profiles.csv")

    for i, (_, req) in enumerate(requests_df.iterrows()):
        req_id = req['request_id']
        user_id = req['user_id']
        req_text = req['request_text']
        requested_amount = float(req['requested_amount'])

        print(f"  [{i+1}/{total}] {req_id} ({user_id})")

        try:
            # Evaluate request
            decision = pipeline.evaluate_request(req_id, is_sample=is_sample)

            # Get profile info for explanation
            profile = profiles[profiles['user_id'] == user_id].iloc[0]
            home_currency = profile['home_currency']
            min_balance = float(profile['minimum_balance_to_keep'])

            # Add metadata for explainer
            decision['_requested_amount'] = requested_amount

            # Generate explanation
            explanation = explainer.explain(decision, req_text, min_balance, home_currency)
            decision['decision_explanation'] = explanation

            # Clean up internal fields
            decision.pop('_requested_amount', None)

            results.append(decision)

        except Exception as e:
            print(f"    [ERROR] {req_id}: {e}")
            import traceback
            traceback.print_exc()
            # Fallback result
            results.append({
                'request_id': req_id,
                'amount_safe_to_pay': 0,
                'affordability_status': 'not_affordable',
                'recommended_payment_method': 'not_recommended',
                'payment_plan': 'none',
                'earliest_date_for_full_payment': '',
                'spending_changes_needed': 'none',
                'decision_explanation': 'Unable to evaluate this request due to an internal error.',
            })

    # Write output.csv
    print(f"\n[4/5] Writing output.csv...")
    output_df = pd.DataFrame(results)
    cols = [
        'request_id', 'amount_safe_to_pay', 'affordability_status',
        'recommended_payment_method', 'payment_plan',
        'earliest_date_for_full_payment', 'spending_changes_needed',
        'decision_explanation'
    ]
    output_df = output_df[cols]
    output_path = os.path.join(data_dir, 'output.csv')
    output_df.to_csv(output_path, index=False)
    print(f"  Output saved to {output_path}")

    # Write usage report
    print(f"[5/5] Writing usage report...")
    elapsed = time.time() - start_time

    ocr_usage = ocr_service.get_usage()
    exp_usage = explainer.get_usage()

    total_calls = ocr_usage['calls'] + exp_usage['calls']
    total_input = ocr_usage['input_tokens'] + exp_usage['input_tokens']
    total_output = ocr_usage['output_tokens'] + exp_usage['output_tokens']
    total_tokens = total_input + total_output

    # Estimate cost (gemini-2.5-flash pricing approx)
    # Input: $0.15 per 1M tokens, Output: $0.60 per 1M tokens
    est_cost_input = (total_input / 1_000_000) * 0.15
    est_cost_output = (total_output / 1_000_000) * 0.60
    est_cost_total = est_cost_input + est_cost_output
    avg_tokens = total_tokens / total if total > 0 else 0
    avg_cost = est_cost_total / total if total > 0 else 0

    report = f"""# Usage Report

## Run Summary
- **Total Requests Processed**: {total}
- **Total Runtime**: {elapsed:.1f} seconds
- **Model**: gemini-2.5-flash (Google GenAI)

## Token Usage by Purpose

### OCR / Image Amount Extraction
- **Model**: {ocr_usage['model']}
- **Calls**: {ocr_usage['calls']}
- **Input Tokens**: {ocr_usage['input_tokens']:,}
- **Output Tokens**: {ocr_usage['output_tokens']:,}

### Decision Explanation Generation
- **Model**: {exp_usage['model']}
- **Calls**: {exp_usage['calls']}
- **Input Tokens**: {exp_usage['input_tokens']:,}
- **Output Tokens**: {exp_usage['output_tokens']:,}

## Overall Totals
- **Total Model Calls**: {total_calls}
- **Total Input Tokens**: {total_input:,}
- **Total Output Tokens**: {total_output:,}
- **Total Tokens**: {total_tokens:,}
- **Average Tokens per Request**: {avg_tokens:,.0f}
- **Estimated Total Cost**: ${est_cost_total:.4f}
- **Estimated Cost per Request**: ${avg_cost:.6f}
"""

    eval_dir = os.path.join(os.path.dirname(__file__), 'evaluation')
    os.makedirs(eval_dir, exist_ok=True)
    report_path = os.path.join(eval_dir, 'usage_report.md')
    with open(report_path, 'w') as f:
        f.write(report)
    print(f"  Usage report saved to {report_path}")

    print(f"\n{'=' * 60}")
    print(f"Done! Processed {total} requests in {elapsed:.1f}s.")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
