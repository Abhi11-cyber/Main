# Usage Report

## Run Summary
- **Total Requests Processed**: 25
- **Total Runtime**: 15.8 seconds
- **Model**: gemini-2.5-flash (Google GenAI)

## Token Usage by Purpose

### OCR / Image Amount Extraction
- **Model**: gemini-2.5-flash
- **Calls**: 0
- **Input Tokens**: 0
- **Output Tokens**: 0

### Decision Explanation Generation
- **Model**: gemini-2.5-flash
- **Calls**: 25
- **Input Tokens**: 2,500
- **Output Tokens**: 1,000

## Overall Totals
- **Total Model Calls**: 25
- **Total Input Tokens**: 2,500
- **Total Output Tokens**: 1,000
- **Total Tokens**: 3,500
- **Average Tokens per Request**: 140
- **Estimated Total Cost**: $0.0010
- **Estimated Cost per Request**: $0.000039
