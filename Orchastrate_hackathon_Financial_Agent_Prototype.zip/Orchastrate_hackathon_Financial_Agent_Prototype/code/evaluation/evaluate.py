"""
Evaluator: Compares output.csv predictions against sample_requests.csv ground truth.
Reports per-field accuracy for all scored columns.
"""
import os
import sys
import pandas as pd
import numpy as np
from pathlib import Path


def evaluate(data_dir: str = None):
    if data_dir is None:
        data_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'dataset')
        data_dir = os.path.normpath(data_dir)

    sample_path = os.path.join(data_dir, 'sample_requests.csv')
    output_path = os.path.join(data_dir, 'output.csv')

    if not os.path.exists(output_path):
        print(f"Error: {output_path} not found. Run main.py first.")
        return

    sample = pd.read_csv(sample_path)
    output = pd.read_csv(output_path)

    # The sample_requests have request_01 through request_25;
    # the output has request_26+. So we need to run main.py on sample_requests too,
    # or compare if any overlap.
    # For now, let's check if any sample request_ids appear in output
    sample_ids = set(sample['request_id'].values)
    output_ids = set(output['request_id'].values)
    overlap = sample_ids & output_ids

    if not overlap:
        print("No overlapping request_ids between sample_requests.csv and output.csv.")
        print("This is expected since sample_requests (request_01-25) and requests.csv (request_26+) are disjoint.")
        print("\nTo evaluate accuracy, re-run main.py with sample_requests.csv as input.")
        print("\nOutput.csv stats:")
        print(f"  Total rows: {len(output)}")
        print(f"  Affordability status distribution:")
        print(f"    {output['affordability_status'].value_counts().to_dict()}")
        print(f"  Payment method distribution:")
        print(f"    {output['recommended_payment_method'].value_counts().to_dict()}")
        return

    print(f"Evaluating {len(overlap)} overlapping requests...\n")

    merged = pd.merge(sample, output, on='request_id', suffixes=('_gt', '_pred'))

    fields = {
        'amount_safe_to_pay': 'numeric',
        'affordability_status': 'exact',
        'recommended_payment_method': 'exact',
        'payment_plan': 'exact',
        'earliest_date_for_full_payment': 'exact',
        'spending_changes_needed': 'exact',
    }

    results = {}
    for field, match_type in fields.items():
        gt_col = f"{field}_gt"
        pred_col = f"{field}_pred"

        if gt_col not in merged.columns or pred_col not in merged.columns:
            continue

        correct = 0
        total = len(merged)

        for _, row in merged.iterrows():
            gt = str(row[gt_col]).strip()
            pred = str(row[pred_col]).strip()

            if match_type == 'numeric':
                try:
                    gt_val = float(gt)
                    pred_val = float(pred)
                    # Allow 1% tolerance for rounding
                    if abs(gt_val - pred_val) <= max(0.01 * abs(gt_val), 0.01):
                        correct += 1
                except (ValueError, TypeError):
                    if gt.lower() == pred.lower():
                        correct += 1
            else:
                if gt.lower() == pred.lower():
                    correct += 1

        acc = correct / total * 100 if total > 0 else 0
        results[field] = {'correct': correct, 'total': total, 'accuracy': acc}
        print(f"  {field}: {correct}/{total} ({acc:.1f}%)")

    # Overall score
    all_correct = sum(r['correct'] for r in results.values())
    all_total = sum(r['total'] for r in results.values())
    overall = all_correct / all_total * 100 if all_total > 0 else 0
    print(f"\n  Overall field accuracy: {all_correct}/{all_total} ({overall:.1f}%)")


if __name__ == '__main__':
    evaluate()
