"""
Pipeline: Evaluates payment plans and selects the best recommendation.

Implements:
  - Full payment evaluation
  - Partial payment evaluation (2-payment schedule)
  - Installment plan evaluation (matching request_payment_options.csv)
  - Wait evaluation
  - Spending change analysis (stop/reduce up to 3 flexible events)
  - Strict tie-breaking hierarchy per problem spec
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple


class Pipeline:
    def __init__(self, simulator, data_dir: str = 'dataset'):
        self.simulator = simulator
        self.requests = pd.read_csv(f"{data_dir}/requests.csv")
        self.sample_requests = pd.read_csv(f"{data_dir}/sample_requests.csv")
        self.payment_options = pd.read_csv(f"{data_dir}/request_payment_options.csv")
        self.profiles = pd.read_csv(f"{data_dir}/financial_profiles.csv")

        # Parse dates in payment_options
        self.payment_options['first_payment_date'] = pd.to_datetime(
            self.payment_options['first_payment_date'], errors='coerce'
        )

    def _get_user_methods(self, user_id: str) -> set:
        """Get the set of payment methods the user will consider."""
        profile = self.profiles[self.profiles['user_id'] == user_id].iloc[0]
        raw = str(profile['payment_methods_user_will_consider'])
        return set(m.strip() for m in raw.split('|') if m.strip())

    def _get_max_installment_months(self, user_id: str) -> Optional[int]:
        """Get max installment months; None means user won't consider installments."""
        profile = self.profiles[self.profiles['user_id'] == user_id].iloc[0]
        val = profile.get('max_installment_months', np.nan)
        if pd.notna(val):
            return int(val)
        return None

    def _check_installment_safe(self, forecast: pd.DataFrame, min_balance: float,
                                 option: pd.Series) -> bool:
        """
        Check if an installment plan is safe: every payment date must keep
        the balance >= min_balance after subtracting the payment.
        """
        start_date = pd.to_datetime(option['first_payment_date'])
        n_payments = int(option['number_of_payments'])
        freq_days = option.get('payment_frequency_days', np.nan)
        per_payment = float(option['payment_amount'])

        if pd.isna(freq_days) or pd.isna(n_payments):
            return False

        freq_days = int(freq_days)

        # Generate payment schedule
        payment_dates = []
        for i in range(n_payments):
            pdate = start_date + timedelta(days=i * freq_days)
            payment_dates.append(pdate)

        # Check each payment against the forecast
        cumulative_paid = 0.0
        for pdate in payment_dates:
            cumulative_paid += per_payment
            # Find balance on or after this date
            if pdate in forecast.index:
                balance_on_date = forecast.loc[pdate, 'balance']
            else:
                # Find nearest date in forecast
                future = forecast[forecast.index >= pdate]
                if future.empty:
                    return False
                balance_on_date = future.iloc[0]['balance']

            # After this payment and all prior ones, check remaining balance from this point
            remaining_forecast = forecast[forecast.index >= pdate]
            if remaining_forecast.empty:
                return False

            min_remaining = remaining_forecast['balance'].min() - cumulative_paid
            if min_remaining < min_balance:
                return False

        return True

    def _get_installment_plan_str(self, option: pd.Series) -> str:
        """Build the plan string for an installment option."""
        start_date = pd.to_datetime(option['first_payment_date'])
        n_payments = int(option['number_of_payments'])
        freq_days = int(option['payment_frequency_days'])
        per_payment = float(option['payment_amount'])

        parts = []
        for i in range(n_payments):
            pdate = start_date + timedelta(days=i * freq_days)
            parts.append(f"{pdate.strftime('%Y-%m-%d')}:{per_payment}")
        return '|'.join(parts)

    def _get_installment_completion_date(self, option: pd.Series) -> pd.Timestamp:
        """Get the last payment date of an installment plan."""
        start_date = pd.to_datetime(option['first_payment_date'])
        n_payments = int(option['number_of_payments'])
        freq_days = int(option['payment_frequency_days'])
        return start_date + timedelta(days=(n_payments - 1) * freq_days)

    def evaluate_request(self, request_id: str, is_sample: bool = False) -> dict:
        """
        Evaluate a single request and return the full output dict.
        """
        # Load request
        if is_sample:
            req_df = self.sample_requests
        else:
            req_df = self.requests

        req = req_df[req_df['request_id'] == request_id].iloc[0]
        user_id = req['user_id']
        request_date = str(req['request_date'])
        requested_amount = float(req['requested_amount'])
        desired_completion = str(req['desired_completion_date'])
        allows_partial = str(req['allows_partial_payment']).strip().lower() == 'true'

        # User preferences
        methods = self._get_user_methods(user_id)
        max_inst_months = self._get_max_installment_months(user_id)

        # Build baseline forecast (no spending changes)
        forecast, min_balance = self.simulator.build_forecast(user_id, request_date)

        # Compute base metrics
        amount_safe = self.simulator.compute_amount_safe_to_pay(forecast, min_balance, requested_amount)
        earliest_full = self.simulator.find_earliest_full_payment_date(forecast, min_balance, requested_amount)

        request_date_ts = pd.to_datetime(request_date)
        desired_completion_ts = pd.to_datetime(desired_completion)

        # ---- Collect all candidate plans ----
        # Each plan: (method, status, plan_str, total_paid, start_date, n_payments,
        #             payment_option_id, completes_by_deadline, spending_changes, earliest_full_for_output)
        candidates = []

        # --- FULL PAYMENT ---
        if 'full_payment' in methods:
            if amount_safe >= requested_amount:
                plan_str = f"{request_date}:{requested_amount}"
                candidates.append({
                    'method': 'full_payment',
                    'status': 'affordable_now',
                    'plan_str': plan_str,
                    'total_paid': requested_amount,
                    'start_date': request_date_ts,
                    'n_payments': 1,
                    'option_id': '',
                    'completes_by_deadline': True,
                    'spending_changes': 'none',
                    'amount_safe': amount_safe,
                    'earliest_full': request_date,
                })

        # --- PARTIAL PAYMENT ---
        if 'partial_payment' in methods and allows_partial:
            if 0 < amount_safe < requested_amount and earliest_full:
                earliest_full_ts = pd.to_datetime(earliest_full)
                if earliest_full_ts <= desired_completion_ts:
                    remainder = round(requested_amount - amount_safe, 2)
                    plan_str = f"{request_date}:{amount_safe}|{earliest_full}:{remainder}"
                    candidates.append({
                        'method': 'partial_payment',
                        'status': 'affordable_with_plan',
                        'plan_str': plan_str,
                        'total_paid': requested_amount,
                        'start_date': request_date_ts,
                        'n_payments': 2,
                        'option_id': '',
                        'completes_by_deadline': True,
                        'spending_changes': 'none',
                        'amount_safe': amount_safe,
                        'earliest_full': earliest_full,
                    })

        # --- INSTALLMENTS ---
        if 'installments' in methods:
            req_options = self.payment_options[
                self.payment_options['request_id'] == request_id
            ].copy()

            # Filter to installment options only
            inst_options = req_options[req_options['payment_method'] == 'installments']

            for _, option in inst_options.iterrows():
                # Check max_installment_months constraint
                if max_inst_months is not None:
                    n_payments = int(option['number_of_payments'])
                    freq_days = int(option['payment_frequency_days'])
                    total_days = n_payments * freq_days
                    total_months = total_days / 30.0
                    if total_months > max_inst_months:
                        continue

                # Check if plan completes by deadline
                completion_date = self._get_installment_completion_date(option)
                completes_by = completion_date <= desired_completion_ts

                # Check if plan is safe against forecast
                if self._check_installment_safe(forecast, min_balance, option):
                    plan_str = self._get_installment_plan_str(option)
                    total_payable = float(option['total_payable_amount'])
                    start = pd.to_datetime(option['first_payment_date'])
                    n_pay = int(option['number_of_payments'])
                    opt_id = option['payment_option_id']

                    candidates.append({
                        'method': 'installments',
                        'status': 'affordable_with_plan',
                        'plan_str': plan_str,
                        'total_paid': total_payable,
                        'start_date': start,
                        'n_payments': n_pay,
                        'option_id': opt_id,
                        'completes_by_deadline': completes_by,
                        'spending_changes': 'none',
                        'amount_safe': amount_safe,
                        'earliest_full': earliest_full,
                    })

        # --- WAIT ---
        if 'full_payment' in methods or 'wait' in methods:
            if earliest_full and earliest_full > request_date:
                earliest_full_ts = pd.to_datetime(earliest_full)
                completes_by = earliest_full_ts <= desired_completion_ts
                if completes_by:
                    status = 'affordable_later'
                    plan_str = f"{earliest_full}:{requested_amount}"
                    candidates.append({
                        'method': 'wait',
                        'status': status,
                        'plan_str': plan_str,
                        'total_paid': requested_amount,
                        'start_date': earliest_full_ts,
                        'n_payments': 1,
                        'option_id': '',
                        'completes_by_deadline': completes_by,
                        'spending_changes': 'none',
                        'amount_safe': amount_safe,
                        'earliest_full': earliest_full,
                    })

        # --- SPENDING CHANGES ---
        # If no plan is viable yet, or we want to try spending changes to enable better plans
        if not candidates or not any(c['completes_by_deadline'] for c in candidates):
            sc_candidates = self._evaluate_with_spending_changes(
                user_id, request_id, request_date, requested_amount,
                desired_completion, allows_partial, methods, max_inst_months,
                forecast, min_balance
            )
            candidates.extend(sc_candidates)

        # ---- Select best plan using tie-breaking ----
        if not candidates:
            return {
                'request_id': request_id,
                'amount_safe_to_pay': amount_safe,
                'affordability_status': 'not_affordable',
                'recommended_payment_method': 'not_recommended',
                'payment_plan': 'none',
                'earliest_date_for_full_payment': earliest_full,
                'spending_changes_needed': 'none',
            }

        best = self._select_best_plan(candidates)

        return {
            'request_id': request_id,
            'amount_safe_to_pay': best['amount_safe'],
            'affordability_status': best['status'],
            'recommended_payment_method': best['method'],
            'payment_plan': best['plan_str'],
            'earliest_date_for_full_payment': best['earliest_full'],
            'spending_changes_needed': best['spending_changes'],
        }

    def _evaluate_with_spending_changes(self, user_id, request_id, request_date,
                                         requested_amount, desired_completion,
                                         allows_partial, methods, max_inst_months,
                                         base_forecast, base_min_balance) -> list:
        """
        Try combinations of spending changes (up to 3) and re-evaluate plans.
        """
        flexible = self.simulator.get_flexible_events(user_id, request_date)
        if not flexible:
            return []

        candidates = []
        request_date_ts = pd.to_datetime(request_date)
        desired_completion_ts = pd.to_datetime(desired_completion)

        # Try single changes, then pairs, then triples (up to 3)
        from itertools import combinations

        # Build all possible single actions
        actions = []
        for fe in flexible[:6]:  # Limit search space
            if fe['can_stop']:
                actions.append(('stop', fe['event_id'], None, fe))
            if fe['can_reduce'] and fe['reduce_to_amount'] is not None:
                actions.append(('reduce', fe['event_id'], fe['reduce_to_amount'], fe))

        # Try combinations of 1, 2, 3
        for size in range(1, min(4, len(actions) + 1)):
            for combo in combinations(actions, size):
                # Check mutual exclusivity: no same event_id with both stop and reduce
                event_ids_in_combo = [a[1] for a in combo]
                if len(set(event_ids_in_combo)) != len(event_ids_in_combo):
                    continue

                # Build exclusion/reduction sets
                excluded = set()
                reduced = {}
                changes_str_parts = []

                for action_type, eid, new_amt, fe_info in combo:
                    if action_type == 'stop':
                        excluded.add(eid)
                        changes_str_parts.append(f"stop:{eid}")
                    else:
                        reduced[eid] = new_amt
                        changes_str_parts.append(f"reduce_to:{eid}:{new_amt}")

                spending_changes_str = '|'.join(changes_str_parts)

                # Re-run forecast with spending changes
                forecast, min_balance = self.simulator.build_forecast(
                    user_id, request_date,
                    excluded_event_ids=excluded,
                    reduced_events=reduced
                )

                amount_safe = self.simulator.compute_amount_safe_to_pay(forecast, min_balance, requested_amount)
                earliest_full = self.simulator.find_earliest_full_payment_date(forecast, min_balance, requested_amount)

                # Re-evaluate plans with modified forecast
                # Full payment with spending changes
                if 'full_payment' in methods and amount_safe >= requested_amount:
                    plan_str = f"{request_date}:{requested_amount}"
                    candidates.append({
                        'method': 'full_payment',
                        'status': 'affordable_with_plan',
                        'plan_str': plan_str,
                        'total_paid': requested_amount,
                        'start_date': request_date_ts,
                        'n_payments': 1,
                        'option_id': '',
                        'completes_by_deadline': True,
                        'spending_changes': spending_changes_str,
                        'amount_safe': amount_safe,
                        'earliest_full': earliest_full if earliest_full else request_date,
                    })

                # Installments with spending changes
                if 'installments' in methods:
                    req_options = self.payment_options[
                        self.payment_options['request_id'] == request_id
                    ]
                    inst_options = req_options[req_options['payment_method'] == 'installments']

                    for _, option in inst_options.iterrows():
                        if max_inst_months is not None:
                            n_payments = int(option['number_of_payments'])
                            freq_days = int(option['payment_frequency_days'])
                            total_months = (n_payments * freq_days) / 30.0
                            if total_months > max_inst_months:
                                continue

                        completion_date = self._get_installment_completion_date(option)
                        completes_by = completion_date <= desired_completion_ts

                        if self._check_installment_safe(forecast, min_balance, option):
                            plan_str = self._get_installment_plan_str(option)
                            candidates.append({
                                'method': 'installments',
                                'status': 'affordable_with_plan',
                                'plan_str': plan_str,
                                'total_paid': float(option['total_payable_amount']),
                                'start_date': pd.to_datetime(option['first_payment_date']),
                                'n_payments': int(option['number_of_payments']),
                                'option_id': option['payment_option_id'],
                                'completes_by_deadline': completes_by,
                                'spending_changes': spending_changes_str,
                                'amount_safe': amount_safe,
                                'earliest_full': earliest_full,
                            })

                # Partial payment with spending changes
                if 'partial_payment' in methods and allows_partial:
                    if 0 < amount_safe < requested_amount and earliest_full:
                        ef_ts = pd.to_datetime(earliest_full)
                        if ef_ts <= desired_completion_ts:
                            remainder = round(requested_amount - amount_safe, 2)
                            plan_str = f"{request_date}:{amount_safe}|{earliest_full}:{remainder}"
                            candidates.append({
                                'method': 'partial_payment',
                                'status': 'affordable_with_plan',
                                'plan_str': plan_str,
                                'total_paid': requested_amount,
                                'start_date': request_date_ts,
                                'n_payments': 2,
                                'option_id': '',
                                'completes_by_deadline': True,
                                'spending_changes': spending_changes_str,
                                'amount_safe': amount_safe,
                                'earliest_full': earliest_full,
                            })

        return candidates

    def _select_best_plan(self, candidates: list) -> dict:
        """
        Apply the tie-breaking hierarchy:
        1. Completes full request by desired_completion_date
        2. Requires zero spending changes
        3. Minimizes total amount paid
        4. Starts payment earlier
        5. Uses fewer payments
        6. Lowest payment_option_id
        """

        def sort_key(c):
            # 1. Completes by deadline (True < False, so negate: False = 0, True = 1 => negate)
            k1 = 0 if c['completes_by_deadline'] else 1
            # 2. No spending changes preferred
            k2 = 0 if c['spending_changes'] == 'none' else 1
            # 3. Minimize total paid
            k3 = c['total_paid']
            # 4. Start earlier
            k4 = c['start_date']
            # 5. Fewer payments
            k5 = c['n_payments']
            # 6. Lowest option_id
            k6 = c['option_id'] if c['option_id'] else ''
            return (k1, k2, k3, k4, k5, k6)

        candidates.sort(key=sort_key)
        return candidates[0]
