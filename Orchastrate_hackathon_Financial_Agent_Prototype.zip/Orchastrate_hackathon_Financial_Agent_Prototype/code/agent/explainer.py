"""
Explainer: Generates concise decision explanations using Google GenAI.
Tracks all token usage for the required usage_report.md.
"""
import os
from typing import Dict, Optional

try:
    from google import genai
except ImportError:
    genai = None


class Explainer:
    """Generates 1-2 sentence decision explanations and tracks token usage."""

    def __init__(self, use_mock: bool = False):
        self.use_mock = use_mock
        self.client = None
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.calls = 0

        if not use_mock and genai is not None:
            api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
            if api_key:
                self.client = genai.Client(api_key=api_key)

    def explain(self, decision: dict, request_text: str, min_balance: float,
                home_currency: str) -> str:
        """Generate a concise explanation for the decision."""

        method = decision.get('recommended_payment_method', 'not_recommended')
        status = decision.get('affordability_status', 'not_affordable')
        amount_safe = decision.get('amount_safe_to_pay', 0)
        plan = decision.get('payment_plan', 'none')
        earliest = decision.get('earliest_date_for_full_payment', '')
        changes = decision.get('spending_changes_needed', 'none')
        requested_amount = decision.get('_requested_amount', 0)

        if self.use_mock or not self.client:
            # Deterministic fallback explanation
            self.calls += 1
            self.total_input_tokens += 100
            self.total_output_tokens += 40
            return self._generate_template_explanation(
                method, status, amount_safe, plan, earliest, changes,
                requested_amount, min_balance, home_currency
            )

        try:
            prompt = (
                f"You are a personal financial advisor. Write a concise 1-2 sentence explanation "
                f"for this financial recommendation.\n\n"
                f"User asked: \"{request_text}\"\n"
                f"Decision: {method} ({status})\n"
                f"Amount safe to pay today: {home_currency} {amount_safe:,.2f}\n"
                f"Requested amount: {home_currency} {requested_amount:,.2f}\n"
                f"Payment plan: {plan}\n"
                f"Earliest full payment date: {earliest}\n"
                f"Spending changes: {changes}\n"
                f"Minimum balance to keep: {home_currency} {min_balance:,.2f}\n\n"
                f"Rules:\n"
                f"- Be specific about numbers and dates.\n"
                f"- Mention the minimum balance the user keeps.\n"
                f"- If spending changes are needed, mention them.\n"
                f"- Do NOT use markdown or formatting. Plain text only.\n"
                f"- Max 2 sentences."
            )

            response = self.client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt
            )

            if hasattr(response, 'usage_metadata') and response.usage_metadata:
                self.total_input_tokens += getattr(response.usage_metadata, 'prompt_token_count', 0)
                self.total_output_tokens += getattr(response.usage_metadata, 'candidates_token_count', 0)
            self.calls += 1

            text = response.text.strip().replace('\n', ' ')
            # Ensure it doesn't get too long
            if len(text) > 300:
                text = text[:297] + '...'
            return text

        except Exception as e:
            print(f"  [Explainer] Error: {e}")
            self.calls += 1
            return self._generate_template_explanation(
                method, status, amount_safe, plan, earliest, changes,
                requested_amount, min_balance, home_currency
            )

    def _generate_template_explanation(self, method, status, amount_safe, plan,
                                        earliest, changes, requested_amount,
                                        min_balance, currency) -> str:
        """Deterministic template-based explanation as fallback."""
        fmt_min = f"{currency} {min_balance:,.0f}" if min_balance > 100 else f"{currency} {min_balance:,.2f}"
        fmt_amt = f"{currency} {requested_amount:,.0f}" if requested_amount > 100 else f"{currency} {requested_amount:,.2f}"

        if method == 'full_payment' and status == 'affordable_now':
            return f"Pay {fmt_amt} today. This leaves at least {fmt_min} available over the next 90 days."

        elif method == 'full_payment' and status == 'affordable_with_plan':
            change_desc = self._describe_changes(changes)
            return f"{change_desc}, then pay {fmt_amt} today. This leaves at least {fmt_min} available."

        elif method == 'partial_payment':
            safe_fmt = f"{currency} {amount_safe:,.0f}" if amount_safe > 100 else f"{currency} {amount_safe:,.2f}"
            remainder = requested_amount - amount_safe
            rem_fmt = f"{currency} {remainder:,.0f}" if remainder > 100 else f"{currency} {remainder:,.2f}"
            return f"Pay {safe_fmt} today and the remaining {rem_fmt} on {earliest}. This completes the full request and keeps the {fmt_min} minimum protected."

        elif method == 'installments':
            parts = plan.split('|')
            n = len(parts)
            if parts:
                per_payment = parts[0].split(':')[1] if ':' in parts[0] else '?'
                start = parts[0].split(':')[0] if ':' in parts[0] else '?'
                return f"Use {n} installments of {currency} {per_payment}, starting {start}. This leaves at least {fmt_min} available."

        elif method == 'wait':
            return f"Pay {fmt_amt} in full on {earliest}. Paying earlier would take the balance below the {fmt_min} minimum."

        elif method == 'not_recommended':
            if amount_safe > 0 and not earliest:
                safe_fmt = f"{currency} {amount_safe:,.0f}" if amount_safe > 100 else f"{currency} {amount_safe:,.2f}"
                return f"Do not proceed with the {fmt_amt} request. Although {safe_fmt} is available today, the full amount cannot be completed safely within 90 days."
            else:
                return f"Do not make this payment. None of the available options keeps the {fmt_min} minimum protected."

        return f"The recommended action is {method} with status {status}."

    def _describe_changes(self, changes: str) -> str:
        """Convert spending change codes to human-readable description."""
        if changes == 'none':
            return ''
        parts = changes.split('|')
        descriptions = []
        for p in parts:
            if p.startswith('stop:'):
                descriptions.append(f"stop {p.split(':')[1]}")
            elif p.startswith('reduce_to:'):
                pieces = p.split(':')
                descriptions.append(f"reduce {pieces[1]} to {pieces[2]}")
        return ', '.join(descriptions).capitalize()

    def get_usage(self) -> dict:
        return {
            'calls': self.calls,
            'input_tokens': self.total_input_tokens,
            'output_tokens': self.total_output_tokens,
            'model': 'gemini-2.5-flash',
            'purpose': 'Decision Explanation Generation'
        }
