"""
Message Parser: Parses natural language messages from messages.csv to identify
if they cancel, delay, or amend financial events.
Uses Google GenAI and caches responses.
"""
import os
import json
import re
from typing import Dict, Optional

try:
    from google import genai
except ImportError:
    genai = None

class MessageParserService:
    def __init__(self, data_dir: str = 'dataset', use_mock: bool = False):
        self.data_dir = data_dir
        self.cache_file = os.path.join(self.data_dir, 'messages_cache.json')
        self.cache: Dict[str, dict] = self._load_cache()
        self.use_mock = use_mock

        self.client = None
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.calls = 0

        if not use_mock and genai is not None:
            api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
            if api_key:
                self.client = genai.Client(api_key=api_key)

    def _load_cache(self) -> Dict[str, dict]:
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save_cache(self):
        os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
        with open(self.cache_file, 'w') as f:
            json.dump(self.cache, f, indent=2)

    def parse_message(self, message_id: str, text: str) -> dict:
        """
        Parses a message and returns a dict with:
        - action: 'cancel', 'amend_amount', 'amend_date', 'amend_both', 'none'
        - new_amount: float or None
        - new_date: str YYYY-MM-DD or None
        """
        if message_id in self.cache:
            return self.cache[message_id]

        default_response = {'action': 'none', 'new_amount': None, 'new_date': None}

        if self.use_mock or not self.client:
            return default_response

        prompt = (
            f"You are a strict financial data extractor. Read this message and determine if it modifies a financial event.\n\n"
            f"Message: \"{text}\"\n\n"
            f"Rules:\n"
            f"- If it explicitly cancels the event or says an expected amount won't happen (like a failed transaction or end of contract), action='cancel'.\n"
            f"- If it changes the amount, action='amend_amount'. Extract the new numeric amount.\n"
            f"- If it changes the date, action='amend_date'. Extract the new date (YYYY-MM-DD).\n"
            f"- If it changes both, action='amend_both'.\n"
            f"- Otherwise, action='none'.\n\n"
            f"Output ONLY a valid JSON object with the exact keys: \"action\", \"new_amount\" (number or null), \"new_date\" (string YYYY-MM-DD or null). "
            f"Do not use markdown blocks, just raw JSON."
        )

        try:
            response = self.client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt
            )

            # Track tokens
            if hasattr(response, 'usage_metadata') and response.usage_metadata:
                self.total_input_tokens += getattr(response.usage_metadata, 'prompt_token_count', 0)
                self.total_output_tokens += getattr(response.usage_metadata, 'candidates_token_count', 0)
            self.calls += 1

            raw = response.text.strip()
            # Clean up potential markdown formatting
            if raw.startswith('```json'):
                raw = raw[7:]
            if raw.startswith('```'):
                raw = raw[3:]
            if raw.endswith('```'):
                raw = raw[:-3]
            
            raw = raw.strip()
            parsed = json.loads(raw)
            
            # Ensure correct types
            result = {
                'action': parsed.get('action', 'none'),
                'new_amount': None,
                'new_date': None
            }
            
            amt = parsed.get('new_amount')
            if amt is not None:
                try:
                    result['new_amount'] = float(amt)
                except ValueError:
                    pass
                    
            dt = parsed.get('new_date')
            if dt and isinstance(dt, str) and len(dt) >= 10:
                # Extract YYYY-MM-DD
                match = re.search(r'\d{4}-\d{2}-\d{2}', dt)
                if match:
                    result['new_date'] = match.group(0)

            self.cache[message_id] = result
            self._save_cache()
            return result

        except Exception as e:
            print(f"  [MessageParser] Error processing {message_id}: {e}")
            self.calls += 1
            return default_response

    def get_usage(self) -> dict:
        return {
            'calls': self.calls,
            'input_tokens': self.total_input_tokens,
            'output_tokens': self.total_output_tokens,
            'model': 'gemini-2.5-flash',
            'purpose': 'Message NLP Parsing'
        }
