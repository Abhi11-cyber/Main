"""
OCR Service: Extracts numeric amounts from receipt/invoice images using Google GenAI.
Uses a persistent JSON cache to avoid redundant API calls.
"""
import os
import json
import re
from pathlib import Path
from typing import Optional, Dict

try:
    from google import genai
except ImportError:
    genai = None

try:
    from PIL import Image
except ImportError:
    Image = None


class OCRService:
    """Extracts financial amounts from images via multimodal LLM."""

    def __init__(self, data_dir: str = 'dataset', use_mock: bool = False):
        self.data_dir = data_dir
        self.image_dir = os.path.join(data_dir, 'media', 'images')
        self.cache_file = os.path.join(self.image_dir, 'ocr_cache.json')
        self.cache: Dict[str, float] = self._load_cache()
        self.use_mock = use_mock

        self.client = None
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.calls = 0

        if not use_mock and genai is not None:
            api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
            if api_key:
                self.client = genai.Client(api_key=api_key)

    def _load_cache(self) -> Dict[str, float]:
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save_cache(self):
        os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
        with open(self.cache_file, 'w') as f:
            json.dump(self.cache, f, indent=2)

    def extract_amount(self, image_id: str) -> Optional[float]:
        """Extract numeric amount from image. Returns None if extraction fails."""
        if image_id in self.cache:
            return float(self.cache[image_id])

        image_path = os.path.join(self.image_dir, f"{image_id}.png")
        if not os.path.exists(image_path):
            print(f"  [OCR] Image file not found: {image_path}")
            return None

        if self.use_mock or not self.client:
            print(f"  [OCR] No API client; cannot extract amount from {image_id}")
            return None

        try:
            pil_img = Image.open(image_path)

            prompt = (
                "This image shows a financial document (receipt, invoice, bill, or bank statement). "
                "Extract the primary monetary amount shown. Return ONLY the numeric value. "
                "Do not include currency symbols, commas, or any text. "
                "If multiple amounts are shown, return the total or main amount. "
                "Example outputs: 1234.56 or 50000"
            )

            response = self.client.models.generate_content(
                model='gemini-2.5-flash',
                contents=[prompt, pil_img]
            )

            # Track token usage
            if hasattr(response, 'usage_metadata') and response.usage_metadata:
                self.total_input_tokens += getattr(response.usage_metadata, 'prompt_token_count', 0)
                self.total_output_tokens += getattr(response.usage_metadata, 'candidates_token_count', 0)
            self.calls += 1

            raw = response.text.strip().replace(',', '').replace(' ', '')
            match = re.search(r'[\d]+(?:\.[\d]+)?', raw)
            if match:
                amount = float(match.group())
                self.cache[image_id] = amount
                self._save_cache()
                print(f"  [OCR] Extracted {amount} from {image_id}")
                return amount
            else:
                print(f"  [OCR] Could not parse amount from response: {raw}")
                return None

        except Exception as e:
            print(f"  [OCR] Error processing {image_id}: {e}")
            return None

    def get_usage(self) -> dict:
        return {
            'calls': self.calls,
            'input_tokens': self.total_input_tokens,
            'output_tokens': self.total_output_tokens,
            'model': 'gemini-2.5-flash',
            'purpose': 'OCR/Image Amount Extraction'
        }
