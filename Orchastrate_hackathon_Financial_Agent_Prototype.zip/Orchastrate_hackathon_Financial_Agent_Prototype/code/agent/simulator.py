"""
Simulator: 90-day deterministic cash-flow forecasting engine.

Builds a day-by-day balance projection for a user from request_date to
request_date + 90 days. Handles:
  - Historical recurrence detection and forward projection
  - Currency conversion via fixed exchange rates
  - OCR-based amount extraction for events with blank amounts
  - Message-based event modifications (cancellation, amendment, delays)
  - Filtering of failed/cancelled/unrealized/pending-credit events
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Optional, Tuple, Dict, List
from collections import defaultdict


class Simulator:
    def __init__(self, data_dir: str = 'dataset', ocr_service=None):
        self.data_dir = data_dir
        self.ocr_service = ocr_service

        # Load all datasets once
        self.profiles = pd.read_csv(f"{data_dir}/financial_profiles.csv")
        self.events = pd.read_csv(f"{data_dir}/financial_events.csv")
        self.exchange_rates = pd.read_csv(f"{data_dir}/exchange_rates.csv")
        self.messages = pd.read_csv(f"{data_dir}/messages.csv")
        self.images = pd.read_csv(f"{data_dir}/images.csv")

        # Preprocess dates
        self.events['event_date'] = pd.to_datetime(self.events['event_date'])
        self.events['settlement_date'] = pd.to_datetime(self.events['settlement_date'], errors='coerce')
        self.exchange_rates['rate_date'] = pd.to_datetime(self.exchange_rates['rate_date'])

        # Fill OCR amounts for events with blank amounts
        self._fill_ocr_amounts()

    def _fill_ocr_amounts(self):
        """For events with blank amount, look up image and extract via OCR."""
        blank_mask = self.events['amount'].isna()
        if not blank_mask.any():
            return

        for idx in self.events[blank_mask].index:
            event_id = self.events.at[idx, 'event_id']
            img_row = self.images[self.images['related_event_id'] == event_id]
            if not img_row.empty and self.ocr_service:
                image_id = img_row.iloc[0]['image_id']
                amount = self.ocr_service.extract_amount(image_id)
                if amount is not None:
                    self.events.at[idx, 'amount'] = amount

    def _get_exchange_rate(self, from_curr: str, to_curr: str, date: pd.Timestamp) -> float:
        """Get exchange rate for a currency pair on or before a given date."""
        if from_curr == to_curr:
            return 1.0

        # Direct rate
        rates = self.exchange_rates[
            (self.exchange_rates['from_currency'] == from_curr) &
            (self.exchange_rates['to_currency'] == to_curr)
        ]
        if not rates.empty:
            on_or_before = rates[rates['rate_date'] <= date]
            if not on_or_before.empty:
                return on_or_before.sort_values('rate_date', ascending=False).iloc[0]['rate']
            return rates.sort_values('rate_date').iloc[0]['rate']

        # Inverse rate
        inv_rates = self.exchange_rates[
            (self.exchange_rates['from_currency'] == to_curr) &
            (self.exchange_rates['to_currency'] == from_curr)
        ]
        if not inv_rates.empty:
            on_or_before = inv_rates[inv_rates['rate_date'] <= date]
            if not on_or_before.empty:
                return 1.0 / on_or_before.sort_values('rate_date', ascending=False).iloc[0]['rate']
            return 1.0 / inv_rates.sort_values('rate_date').iloc[0]['rate']

        # Try USD as intermediary
        rate_to_usd = self._get_direct_rate(from_curr, 'USD', date)
        rate_from_usd = self._get_direct_rate('USD', to_curr, date)
        if rate_to_usd and rate_from_usd:
            return rate_to_usd * rate_from_usd

        return 1.0  # Fallback

    def _get_direct_rate(self, from_curr: str, to_curr: str, date: pd.Timestamp) -> Optional[float]:
        """Try to find a direct rate."""
        if from_curr == to_curr:
            return 1.0
        rates = self.exchange_rates[
            (self.exchange_rates['from_currency'] == from_curr) &
            (self.exchange_rates['to_currency'] == to_curr)
        ]
        if not rates.empty:
            on_or_before = rates[rates['rate_date'] <= date]
            if not on_or_before.empty:
                return on_or_before.sort_values('rate_date', ascending=False).iloc[0]['rate']
            return rates.sort_values('rate_date').iloc[0]['rate']
        # Try inverse
        inv = self.exchange_rates[
            (self.exchange_rates['from_currency'] == to_curr) &
            (self.exchange_rates['to_currency'] == from_curr)
        ]
        if not inv.empty:
            on_or_before = inv[inv['rate_date'] <= date]
            if not on_or_before.empty:
                return 1.0 / on_or_before.sort_values('rate_date', ascending=False).iloc[0]['rate']
            return 1.0 / inv.sort_values('rate_date').iloc[0]['rate']
        return None

    def _convert_amount(self, amount: float, from_curr: str, to_curr: str, date: pd.Timestamp) -> float:
        """Convert amount from one currency to another."""
        if pd.isna(amount):
            return 0.0
        rate = self._get_exchange_rate(from_curr, to_curr, date)
        return amount * rate

    def _detect_recurrence(self, user_events: pd.DataFrame, request_date: pd.Timestamp,
                           home_currency: str) -> List[dict]:
        """
        Detect recurring expense/income patterns from historical events
        and project them forward into the 90-day window.

        Strategy: Group by (category, description, direction).
        If there are >=2 events with regular intervals (~monthly), project forward.
        """
        end_date = request_date + timedelta(days=90)

        # Only look at settled events before request_date for pattern detection
        historical = user_events[
            (user_events['status'] == 'settled') &
            (user_events['event_date'] < request_date)
        ].copy()

        if historical.empty:
            return []

        projected = []
        groups = historical.groupby(['category', 'description', 'direction'])

        for (cat, desc, direction), group in groups:
            group_sorted = group.sort_values('event_date')
            if len(group_sorted) < 2:
                continue

            # Compute intervals
            dates = group_sorted['event_date'].values
            intervals = []
            for i in range(len(dates) - 1):
                delta = (dates[i + 1] - dates[i]) / np.timedelta64(1, 'D')
                intervals.append(delta)

            if not intervals:
                continue

            avg_interval = np.median(intervals)

            # Only project if interval is reasonable (weekly to monthly: 5-35 days)
            if avg_interval < 5 or avg_interval > 35:
                continue

            # Use the last few amounts for average
            recent = group_sorted.tail(3)
            avg_amount = recent['amount'].mean()
            if pd.isna(avg_amount) or avg_amount <= 0:
                continue

            currency = group_sorted.iloc[-1]['currency']
            last_date = pd.Timestamp(dates[-1])
            flexibility = group_sorted.iloc[-1]['flexibility']
            min_allowed = group_sorted.iloc[-1].get('minimum_allowed_amount', np.nan)

            # Project forward from last_date
            next_date = last_date + timedelta(days=int(round(avg_interval)))
            while next_date <= end_date:
                if next_date >= request_date:
                    converted = self._convert_amount(avg_amount, currency, home_currency, next_date)
                    projected.append({
                        'date': next_date,
                        'amount': converted,
                        'direction': direction,
                        'category': cat,
                        'description': desc,
                        'is_projected': True,
                        'flexibility': flexibility,
                        'minimum_allowed_amount': min_allowed,
                        'event_id': group_sorted.iloc[-1]['event_id'],  # Use last event_id for reference
                    })
                next_date = next_date + timedelta(days=int(round(avg_interval)))

        return projected

    def get_user_profile(self, user_id: str) -> pd.Series:
        """Get user profile."""
        return self.profiles[self.profiles['user_id'] == user_id].iloc[0]

    def build_forecast(self, user_id: str, request_date_str: str,
                       excluded_event_ids: set = None,
                       reduced_events: dict = None) -> Tuple[pd.DataFrame, float]:
        """
        Build a 90-day daily balance forecast for the given user starting from request_date.

        Args:
            user_id: The user identifier.
            request_date_str: The request date (YYYY-MM-DD).
            excluded_event_ids: Set of event IDs to exclude (for spending changes: stop).
            reduced_events: Dict of event_id -> new_amount (for spending changes: reduce_to).

        Returns:
            Tuple of (forecast DataFrame with 'date' and 'balance' columns, min_balance).
        """
        request_date = pd.to_datetime(request_date_str)
        end_date = request_date + timedelta(days=90)

        profile = self.get_user_profile(user_id)
        home_currency = profile['home_currency']
        min_balance = float(profile['minimum_balance_to_keep'])
        current_balance = float(profile['current_available_balance'])

        if excluded_event_ids is None:
            excluded_event_ids = set()
        if reduced_events is None:
            reduced_events = {}

        # Get all user events
        user_events = self.events[self.events['user_id'] == user_id].copy()

        # Build daily deltas
        dates = pd.date_range(request_date, end_date)
        daily_delta = defaultdict(float)

        # --- Process actual events (scheduled, pending debits, settled in future) ---
        for _, row in user_events.iterrows():
            event_id = row['event_id']
            status = row['status']
            direction = row['direction']
            amount = row['amount']
            currency = row['currency']
            event_date = row['event_date']
            settlement_date = row['settlement_date']

            # Skip failed, cancelled events
            if status in ('failed', 'cancelled'):
                continue

            # Skip unrealized (non-cash) events
            if status == 'unrealized' or direction == 'non_cash':
                continue

            # Skip pending credits (not settled yet, don't count)
            if status == 'pending' and direction == 'credit':
                continue

            # Skip excluded events (spending changes: stop)
            if event_id in excluded_event_ids:
                continue

            if pd.isna(amount):
                continue

            # Apply reductions
            if event_id in reduced_events:
                amount = reduced_events[event_id]

            # Use settlement_date if available, otherwise event_date
            effective_date = settlement_date if pd.notna(settlement_date) else event_date

            # Only events in the forecast window
            if effective_date < request_date or effective_date > end_date:
                continue

            # Convert currency
            converted = self._convert_amount(amount, currency, home_currency, effective_date)

            if direction == 'debit':
                daily_delta[effective_date] -= converted
            elif direction == 'credit':
                # Only count confirmed income (settled or scheduled salary)
                if status in ('settled', 'scheduled'):
                    daily_delta[effective_date] += converted

        # --- Project recurring patterns ---
        projections = self._detect_recurrence(user_events, request_date, home_currency)
        for proj in projections:
            proj_event_id = proj['event_id']
            if proj_event_id in excluded_event_ids:
                continue

            amount = proj['amount']
            if proj_event_id in reduced_events:
                # The reduction applies to the raw amount; we need to scale
                orig_events = user_events[user_events['event_id'] == proj_event_id]
                if not orig_events.empty:
                    orig_amt = orig_events.iloc[0]['amount']
                    if orig_amt and orig_amt > 0:
                        ratio = reduced_events[proj_event_id] / orig_amt
                        amount = amount * ratio

            d = proj['date']
            if proj['direction'] == 'debit':
                daily_delta[d] -= amount
            else:
                daily_delta[d] += amount

        # Build forecast dataframe
        forecast_data = []
        balance = current_balance
        for d in dates:
            delta = daily_delta.get(d, 0.0)
            balance += delta
            forecast_data.append({'date': d, 'balance': balance, 'delta': delta})

        forecast = pd.DataFrame(forecast_data)
        forecast.set_index('date', inplace=True)

        return forecast, min_balance

    def compute_amount_safe_to_pay(self, forecast: pd.DataFrame, min_balance: float,
                                    requested_amount: float) -> float:
        """
        Compute the maximum lump sum payable on request_date such that
        all future balances remain >= min_balance.

        amount_safe = min(forecast['balance']) - min_balance, clamped to [0, requested_amount].
        """
        min_forecast_balance = forecast['balance'].min()
        buffer = min_forecast_balance - min_balance
        amount_safe = max(0.0, min(requested_amount, buffer))
        return round(amount_safe, 2)

    def find_earliest_full_payment_date(self, forecast: pd.DataFrame, min_balance: float,
                                         requested_amount: float) -> str:
        """
        Find the earliest date D in the forecast window where paying requested_amount
        on date D keeps all subsequent balances >= min_balance.

        Returns YYYY-MM-DD string or empty string.
        """
        for date_val in forecast.index:
            # If we pay on this date, subtract requested_amount from this date onwards
            future_balances = forecast.loc[date_val:]['balance']
            # The minimum future balance after paying
            min_future = future_balances.min() - requested_amount
            if min_future >= min_balance:
                return date_val.strftime('%Y-%m-%d')
        return ""

    def get_flexible_events(self, user_id: str, request_date_str: str) -> List[dict]:
        """
        Get flexible (stoppable/reducible) recurring events for a user
        that fall within the 90-day forecast window.

        Returns a list of dicts with event_id, flexibility, category, amount,
        minimum_allowed_amount, and the projected savings if stopped/reduced.
        """
        request_date = pd.to_datetime(request_date_str)
        end_date = request_date + timedelta(days=90)

        profile = self.get_user_profile(user_id)
        home_currency = profile['home_currency']

        # Categories the user is willing to reduce or stop
        willing_to_reduce = set()
        willing_to_stop = set()
        if pd.notna(profile.get('expense_categories_user_is_willing_to_reduce', '')):
            willing_to_reduce = set(str(profile['expense_categories_user_is_willing_to_reduce']).split('|'))
        if pd.notna(profile.get('expense_categories_user_is_willing_to_stop', '')):
            willing_to_stop = set(str(profile['expense_categories_user_is_willing_to_stop']).split('|'))

        user_events = self.events[self.events['user_id'] == user_id].copy()

        # Find unique flexible events in the forecast window or historically recurring
        flexible_events = []
        seen_ids = set()

        # Look at all events with flexibility != 'fixed'
        for _, row in user_events.iterrows():
            flex = row.get('flexibility', 'fixed')
            if flex == 'fixed' or pd.isna(flex):
                continue

            event_id = row['event_id']
            if event_id in seen_ids:
                continue
            seen_ids.add(event_id)

            category = row['category']
            amount = row['amount']
            min_allowed = row.get('minimum_allowed_amount', np.nan)

            # Check if user is willing
            can_stop = (flex in ('stoppable', 'reducible_or_stoppable')) and (category in willing_to_stop)
            can_reduce = (flex in ('reducible', 'reducible_or_stoppable')) and (category in willing_to_reduce)

            if not can_stop and not can_reduce:
                continue

            if pd.isna(amount) or amount <= 0:
                continue

            converted = self._convert_amount(amount, row['currency'], home_currency, request_date)

            # Count how many future occurrences in 90-day window
            same_cat = user_events[
                (user_events['category'] == category) &
                (user_events['description'] == row['description']) &
                (user_events['event_date'] >= request_date) &
                (user_events['event_date'] <= end_date) &
                (user_events['status'].isin(['settled', 'scheduled', 'pending']))
            ]
            occurrence_count = max(1, len(same_cat))

            # Estimate savings
            stop_savings = converted * occurrence_count if can_stop else 0.0
            reduce_savings = 0.0
            reduce_to_amount = 0.0
            if can_reduce and pd.notna(min_allowed) and min_allowed < amount:
                reduce_to_amount = min_allowed
                reduce_savings = (converted - self._convert_amount(min_allowed, row['currency'], home_currency, request_date)) * occurrence_count

            flexible_events.append({
                'event_id': event_id,
                'category': category,
                'description': row['description'],
                'flexibility': flex,
                'amount': converted,
                'original_amount': amount,
                'currency': row['currency'],
                'minimum_allowed_amount': min_allowed if pd.notna(min_allowed) else None,
                'reduce_to_amount': reduce_to_amount,
                'can_stop': can_stop,
                'can_reduce': can_reduce,
                'stop_savings': stop_savings,
                'reduce_savings': reduce_savings,
            })

        # Sort by savings potential (highest first)
        flexible_events.sort(key=lambda x: max(x['stop_savings'], x['reduce_savings']), reverse=True)

        return flexible_events
